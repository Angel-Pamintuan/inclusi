import openai
import pyttsx3
import speech_recognition as sr
import time
import os

# Initialize OpenAI client
client = openai.OpenAI(api_key="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")

# Initialize text-to-speech engine
engine = pyttsx3.init()

def transcribe_audio_to_text(filename):
    recognizer = sr.Recognizer()
    with sr.AudioFile(filename) as source:
        audio = recognizer.record(source)
    try:
        return recognizer.recognize_google(audio)
    except sr.UnknownValueError:
        print("Sorry, could not understand the audio.")
    except sr.RequestError as e:
        print(f"Error with the speech recognition service: {e}")
    return None

def generate_response(prompt):
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=150,
            temperature=0.7,
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"Error in OpenAI API call: {e}")
        return "Sorry, I couldn't process that."

def speak_text(text):
    engine.say(text)
    engine.runAndWait()

def main():
    recognizer = sr.Recognizer()
    microphone = sr.Microphone()

    while True:
        try:
            print("Say 'Hi' to start recording your question...")
            with microphone as source:
                recognizer.adjust_for_ambient_noise(source)
                audio = recognizer.listen(source)

            try:
                transcription = recognizer.recognize_google(audio).lower()
                print(f"Detected: {transcription}")
            except sr.UnknownValueError:
                print("Could not understand the audio, please try again.")
                continue
            except sr.RequestError as e:
                print(f"Speech recognition error: {e}")
                continue

            if "hi" in transcription:
                print("Listening for your question...")

                with microphone as source:
                    recognizer.adjust_for_ambient_noise(source)
                    audio = recognizer.listen(source, phrase_time_limit=10)

                filename = "input.wav"
                with open(filename, "wb") as f:
                    f.write(audio.get_wav_data())

                text = transcribe_audio_to_text(filename)
                if text:
                    print(f"You said: {text}")
                    response = generate_response(text)
                    print(f"GPT says: {response}")
                    speak_text(response)
            else:
                print("Keyword not detected. Try again.")

        except Exception as e:
            print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
