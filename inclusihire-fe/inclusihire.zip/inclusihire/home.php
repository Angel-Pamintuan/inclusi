<?php
session_start();
$accessibility = isset($_SESSION['accessibility']) ? $_SESSION['accessibility'] : null;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accessibility</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <style>
        .container {
            display: flex;
            flex-direction: column;
            /* Ensures everything stacks properly */
            align-items: center;
            max-width: 400px;
            width: 100%;
            padding: 20px;
        }

        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            padding: 10px;
            margin: 20px 0;
        }

        .title {
            font-size: 18px;
            color: #95969D;
        }

        .profile {
            font-size: 55px;
        }

        .search {
            width: 237px;
            height: 35px;
            border: none;
            background: #F1F1F1;
            border-radius: 10px;
            padding: 5px 10px;
            margin-bottom: 10px;
        }

        button {
            width: 109px;
            height: 35px;
            border: none;
            color: white;
            background: linear-gradient(90.18deg, rgba(89, 156, 244, 0.8) 5.64%, rgba(3, 49, 108, 0.8) 98.35%);
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .heading {
            font-size: 24px;
            font-weight: 600;
            color: #000;
            align-self: flex-start;
            margin-left: 10px;
        }

        .featured-container {
            display: flex;
            gap: 20px;
            overflow-x: auto;
            padding: 10px;
            white-space: nowrap;
            width: 100%;
        }

        .featured {
            width: 300px;
            min-width: 300px;
            height: 200px;
            background: #fff;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            position: relative;
        }

        .logo {
            position: absolute;
            width: 48px;
            height: 45px;
            left: 20px;
            top: 10px;
            background: url(image.png) no-repeat center/cover;
        }

        .job-title {
            position: absolute;
            left: 80px;
            top: 15px;
            font-family: 'SF Pro Display', sans-serif;
            font-weight: 500;
            font-size: 24px;
            color: #000;
        }

        .company-name {
            position: absolute;
            left: 80px;
            top: 45px;
            font-family: 'SF Pro Display', sans-serif;
            font-weight: 400;
            font-size: 14px;
            color: #666;
        }

        .bookmark {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 20px;
            cursor: pointer;
        }

        .job-roles {
            position: absolute;
            left: 20px;
            top: 75px;
            background: #EBEBEB;
            border-radius: 30px;
            padding: 5px 10px;
            font-size: 12px;
        }

        .job-type {
            position: absolute;
            left: 90px;
            top: 75px;
            background: #EBEBEB;
            border-radius: 30px;
            padding: 5px 10px;
            font-size: 12px;
        }

        .short-description {
            display: -webkit-box;
            width: 100%;
            font-family: 'Poppins', sans-serif;
            font-weight: 300;
            font-size: 12px;
            color: #000;
            white-space: normal;
            /* Allows text to wrap */
            word-wrap: break-word;
            /* Breaks long words */
            overflow: hidden;
            -webkit-line-clamp: 3;
            /* Limit to 3 lines */
            -webkit-box-orient: vertical;
            margin-top: 100px;
            /* Prevent overlap with other elements */
        }

        .salary {
            position: absolute;
            left: 20px;
            bottom: 10px;
            font-family: 'SF Pro Display', sans-serif;
            font-size: 12px;
            font-weight: bold;
            color: #28a745;
        }

        .location {
            position: absolute;
            right: 20px;
            bottom: 10px;
            font-family: 'SF Pro Display', sans-serif;
            font-size: 12px;
            color: #000;
        }

        .show-more {
            /* Rectangle 119 */

            position: absolute;
            width: 131px;
            height: 31px;
            left: calc(50% - 131px/2);
            top: 472px;

            background: #1E4461;
            border-radius: 5px;

        }

        .resume {
            /* Rectangle 120 */

            position: absolute;
            width: 345px;
            height: 147px;
            left: 24px;
            top: 558px;

            /* vluuuu */
            background: linear-gradient(90.18deg, rgba(89, 156, 244, 0.8) 5.64%, rgba(3, 49, 108, 0.8) 98.35%);
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.25);
            border-radius: 10px;
            color: white;
            font-size: 24px;

        }

        footer {
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 72px;
            background: #FFFFFF;
            display: flex;
            justify-content: space-around;
            align-items: center;
            box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.1);
            /* Soft shadow on top */
        }

        footer div {
            font-size: 28px;
            /* Make icons bigger */
            cursor: pointer;
            /* Indicate clickable */
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header-container">
            <div class="title">Welcome to InclusiHire!</div>
            <ion-icon name="person-circle-outline" class="profile"></ion-icon>
        </div>
        <div>
            <input type="search" class="search" placeholder=" Search" aria-label="Search">
            <button type="submit">Find Job<ion-icon name="sparkles-outline"></ion-icon></button>
        </div>
        <div class="heading">Featured Jobs</div>

        <div class="featured-container">
            <div class="featured">
                <div class="bookmark"><ion-icon name="bookmark-outline"></ion-icon></div>
                <div class="logo"></div>
                <div class="job-title">Service Crew</div>
                <div class="company-name">McDonald's</div>
                <div class="job-roles">Service</div>
                <div class="job-type">Full-time</div>
                <div class="short-description">A McDonald's service crew takes orders, prepares food, handles payments,
                    and
                    keeps the restaurant clean while ensuring great customer service.</div>
                <div class="salary">₱200,000/Month</div>
                <div class="location">Mexico, Pampanga</div>
            </div>

            <div class="featured">
                <div class="bookmark"><ion-icon name="bookmark-outline"></ion-icon></div>
                <div class="logo"></div>
                <div class="job-title">Cashier</div>
                <div class="company-name">Jollibee</div>
                <div class="job-roles">Cashier</div>
                <div class="job-type">Part-time</div>
                <div class="short-description">Responsible for handling transactions, assisting customers, and
                    maintaining a
                    clean workspace.</div>
                <div class="salary">₱180,000/Month</div>
                <div class="location">San Fernando, Pampanga</div>
            </div>

            <div class="featured">
                <div class="bookmark"><ion-icon name="bookmark-outline"></ion-icon></div>
                <div class="logo"></div>
                <div class="job-title">Barista</div>
                <div class="company-name">Starbucks</div>
                <div class="job-roles">Beverage</div>
                <div class="job-type">Full-time</div>
                <div class="short-description">Prepares drinks, serves customers, and ensures high-quality customer
                    service.</div>
                <div class="salary">₱220,000/Month</div>
                <div class="location">Angeles, Pampanga</div>
            </div>
        </div>

        <button type="button" class="show-more"><a href="morejobs.php">More</a></button>

        <button type="button" class="resume"> <a href="cv.php">Generate Resume<ion-icon
                    name="sparkles-outline"></ion-icon></a></button>



    </div>

    <footer>
        <div><ion-icon name="home-outline" style="color: #1E4461"></ion-icon></div>
        <div><ion-icon name="bookmark-outline"></ion-icon></div>
        <div><ion-icon name="grid-outline"></ion-icon></div>
    </footer>

    <?php if ($accessibility == 'screen_reader'): ?>
        <script>
            const textToRead = document.body.innerText;
            const speech = new SpeechSynthesisUtterance(textToRead);
            speech.lang = "en-US";
            window.speechSynthesis.speak(speech);
        </script>
    <?php elseif ($accessibility == 'voice_control'): ?>
        <script>
            window.SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            const recognition = new SpeechRecognition();
            recognition.continuous = true;
            recognition.start();
            recognition.onresult = (event) => {
                console.log("Voice Command:", event.results[0][0].transcript);
            };
        </script>
    <?php elseif ($accessibility == 'focus_mode'): ?>
        <style>
            body {
                background-color: #f4f4f4;
                font-size: 20px;
            }
        </style>
        <p>Focus mode is enabled. The page is adjusted for better readability.</p>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

    <script src="accessibility.js"></script>
    <script>
        function stopReading() {
            speechSynthesis.cancel(); // Immediately stops any ongoing speech
        }

        document.getElementById("readButton").addEventListener("click", function () {
            stopReading(); // Ensure previous speech stops before starting a new one

            const text = document.body.innerText;
            const speech = new SpeechSynthesisUtterance(text);
            speech.lang = "en-US";
            speech.rate = 1;

            speechSynthesis.speak(speech);
        });
    </script>


</body>

</html>