<?php
session_start();
$accessibility = isset($_SESSION['accessibility']) ? $_SESSION['accessibility'] : null;

include 'database.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch impairment records from database
$sql = "SELECT id_impairment, impairment FROM tbl_impairment";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accessibility</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }

        .title {
            width: 362px;
            height: 137px;

            padding-left: 30px;
            font-weight: 600;
            font-size: 24px;
            line-height: 140%;
            letter-spacing: -0.015em;
            color: #0D0D26;
            margin: 100px auto 10px;
        }

        .form-check {
            display: flex;
            align-items: center;
            justify-content: space-between;
            /* Moves the radio button to the right */
            width: 327px;
            height: 62px;
            margin: 10px auto;
            background: #F2F2F2;
            box-shadow: 0px 2px 10px -2px rgba(13, 21, 38, 0.02);
            border-radius: 12px;
            padding: 10px 20px;
            /* Add padding for better spacing */
            cursor: pointer;
        }

        .form-check-label {
            font-size: 18px;
            color: #333;
        }

        .form-check-input {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        button {
            /* Button */

            /* Auto layout */
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
            padding: 16px 48px;
            gap: 10px;

            position: absolute;
            width: 327px;
            height: 56px;
            left: 33px;
            top: 698px;

            background: #1E4461;
            border-radius: 5px;
            color: white;

        }
    </style>
</head>

<body>
    <div class="container">
        <div class="title">Do you have any of the following conditions that may affect your job search?</div>

        <form action="" method="POST">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $id = $row['id_impairment'];
                    $impairment = $row['impairment'];

                    echo '
                <div class="form-check">
                    <label class="form-check-label" for="radio' . $id . '">' . $impairment . '</label>
                    <input class="form-check-input" type="radio" name="accessibility" value="' . $id . '" id="radio' . $id . '">
                </div>';
                }
            } else {
                echo '<p>No impairments found.</p>';
            }
            ?>

            <button type="submit" onclick="stopReading();">Save</button>
        </form>
    </div>

    <?php if ($accessibility == 'screen_reader'): ?>
        <script>
            const textToRead = document.body.innerText;
            const speech = new SpeechSynthesisUtterance(textToRead);
            speech.lang = "en-US";
            window.speechSynthesis.speak(speech);
        </script>
    <?php elseif ($accessibility == 'voice_control'): ?>
        <script>
            window.SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            const recognition = new SpeechRecognition();
            recognition.continuous = true;
            recognition.start();
            recognition.onresult = (event) => {
                console.log("Voice Command:", event.results[0][0].transcript);
            };
        </script>
    <?php elseif ($accessibility == 'focus_mode'): ?>
        <style>
            body {
                background-color: #f4f4f4;
                font-size: 20px;
            }
        </style>
        <p>Focus mode is enabled. The page is adjusted for better readability.</p>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <script src="accessibility.js"></script>
    <script>
        function stopReading() {
            speechSynthesis.cancel(); // Immediately stops any ongoing speech
        }

        document.getElementById("readButton").addEventListener("click", function () {
            stopReading(); // Ensure previous speech stops before starting a new one

            const text = document.body.innerText;
            const speech = new SpeechSynthesisUtterance(text);
            speech.lang = "en-US";
            speech.rate = 1;

            speechSynthesis.speak(speech);
        });
    </script>


</body>

</html>