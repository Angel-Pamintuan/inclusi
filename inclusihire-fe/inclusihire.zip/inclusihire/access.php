<?php
session_start();

if (isset($_SESSION['accessibility'])) {
    $accessibility = $_SESSION['accessibility'];
} else {
    $accessibility = null;
}
?>

<?php if ($accessibility == 'screen_reader'): ?>
    <script>
        const textToRead = document.body.innerText;
        const speech = new SpeechSynthesisUtterance(textToRead);
        speech.lang = "en-US";
        window.speechSynthesis.speak(speech);
    </script>
<?php elseif ($accessibility == 'voice_control'): ?>
    <script>
        window.SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.start();
        recognition.onresult = (event) => {
            console.log("Voice Command:", event.results[0][0].transcript);
        };
    </script>
<?php elseif ($accessibility == 'focus_mode'): ?>
    <style>
        body {
            background-color: #f4f4f4;
            font-size: 20px;
        }
    </style>
    <p>Focus mode is enabled. The page is adjusted for better readability.</p>
<?php endif; ?>