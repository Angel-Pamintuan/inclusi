<?php
session_start();
$accessibility = isset($_SESSION['accessibility']) ? $_SESSION['accessibility'] : null;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accessibility</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <style>
        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            max-width: 400px;
            width: 100%;
            padding: 20px;
        }

        .heading {
            font-size: 24px;
            font-weight: 600;
            color: #000;
            align-self: flex-start;
            margin-left: 10px;
            margin-top: 10px;
        }

        .featured-container {
            display: flex;
            flex-direction: column;
            gap: 20px;
            overflow-y: auto;
            max-height: 83vh;
            /* Makes it scrollable */
            padding: 10px;
            padding-bottom: 70px;
            width: 100%;
            scrollbar-width: none;
            /* Firefox */
            -ms-overflow-style: none;
            /* IE/Edge */

        }

        .featured {
            width: 100%;
            background: #fff;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            position: relative;
        }

        .logo {
            position: absolute;
            width: 48px;
            height: 45px;
            left: 20px;
            top: 10px;
            background: url(image.png) no-repeat center/cover;
        }

        .job-title {
            position: absolute;
            left: 80px;
            top: 15px;
            font-family: 'SF Pro Display', sans-serif;
            font-weight: 500;
            font-size: 24px;
            color: #000;
        }

        .company-name {
            position: absolute;
            left: 80px;
            top: 45px;
            font-family: 'SF Pro Display', sans-serif;
            font-weight: 400;
            font-size: 14px;
            color: #666;
        }

        .bookmark {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 20px;
            cursor: pointer;
        }

        .job-roles,
        .job-type {
            position: absolute;
            background: #EBEBEB;
            border-radius: 30px;
            padding: 5px 10px;
            font-size: 12px;
        }

        .job-roles {
            left: 20px;
            top: 75px;
        }

        .job-type {
            left: 90px;
            top: 75px;
        }

        .short-description {
            display: -webkit-box;
            width: 100%;
            font-family: 'Poppins', sans-serif;
            font-weight: 300;
            font-size: 12px;
            color: #000;
            white-space: normal;
            word-wrap: break-word;
            overflow: hidden;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            margin-top: 100px;
            margin-bottom: 20px;
        }

        .salary {
            position: absolute;
            left: 20px;
            bottom: 10px;
            font-family: 'SF Pro Display', sans-serif;
            font-size: 12px;
            font-weight: bold;
            color: #28a745;
        }

        .location {
            position: absolute;
            right: 20px;
            bottom: 10px;
            font-family: 'SF Pro Display', sans-serif;
            font-size: 12px;
            color: #000;
        }

        footer {
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 72px;
            background: #FFFFFF;
            display: flex;
            justify-content: space-around;
            align-items: center;
            box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.1);

        }

        footer div {
            font-size: 28px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="heading"><a href="home.php" style="color: black;"><ion-icon
                    name="arrow-back-outline"></ion-icon></a></div>

        <div class="featured-container">
            <div class="heading">Discover Jobs</div>
            <div class="featured">
                <div class="bookmark"><ion-icon name="bookmark-outline"></ion-icon></div>
                <div class="logo"></div>
                <div class="job-title">Service Crew</div>
                <div class="company-name">McDonald's</div>
                <div class="job-roles">Service</div>
                <div class="job-type">Full-time</div>
                <div class="short-description">A McDonald's service crew takes orders, prepares food, handles payments,
                    and
                    keeps the restaurant clean while ensuring great customer service.</div>
                <div class="salary">₱200,000/Month</div>
                <div class="location">Mexico, Pampanga</div>
            </div>

            <div class="featured">
                <div class="bookmark"><ion-icon name="bookmark-outline"></ion-icon></div>
                <div class="logo"></div>
                <div class="job-title">Cashier</div>
                <div class="company-name">Jollibee</div>
                <div class="job-roles">Cashier</div>
                <div class="job-type">Part-time</div>
                <div class="short-description">Responsible for handling transactions, assisting customers, and
                    maintaining a
                    clean workspace.</div>
                <div class="salary">₱180,000/Month</div>
                <div class="location">San Fernando, Pampanga</div>
            </div>

            <div class="featured">
                <div class="bookmark"><ion-icon name="bookmark-outline"></ion-icon></div>
                <div class="logo"></div>
                <div class="job-title">Barista</div>
                <div class="company-name">Starbucks</div>
                <div class="job-roles">Beverage</div>
                <div class="job-type">Full-time</div>
                <div class="short-description">Prepares drinks, serves customers, and ensures high-quality customer
                    service.</div>
                <div class="salary">₱220,000/Month</div>
                <div class="location">Angeles, Pampanga</div>
            </div>

            <div class="featured">
                <div class="bookmark"><ion-icon name="bookmark-outline"></ion-icon></div>
                <div class="logo"></div>
                <div class="job-title">Software Engineer</div>
                <div class="company-name">Google</div>
                <div class="job-roles">IT</div>
                <div class="job-type">Full-time</div>
                <div class="short-description">Develops software solutions, writes clean code, and collaborates with
                    teams to enhance Google's products.</div>
                <div class="salary">₱500,000/Month</div>
                <div class="location">Manila, Philippines</div>
            </div>

            <div class="featured">
                <div class="bookmark"><ion-icon name="bookmark-outline"></ion-icon></div>
                <div class="logo"></div>
                <div class="job-title">Graphic Designer</div>
                <div class="company-name">Canva</div>
                <div class="job-roles">Design</div>
                <div class="job-type">Remote</div>
                <div class="short-description">Creates visual content, UI elements, and brand designs for Canva's
                    platform and marketing campaigns.</div>
                <div class="salary">₱350,000/Month</div>
                <div class="location">Remote</div>
            </div>
        </div>


    </div>

    <footer>
        <div><ion-icon name="home-outline" style="color: #1E4461"></ion-icon></div>
        <div><ion-icon name="bookmark-outline"></ion-icon></div>
        <div><ion-icon name="grid-outline"></ion-icon></div>
    </footer>

    <?php if ($accessibility == 'screen_reader'): ?>
        <script>
            const textToRead = document.body.innerText;
            const speech = new SpeechSynthesisUtterance(textToRead);
            speech.lang = "en-US";
            window.speechSynthesis.speak(speech);
        </script>
    <?php elseif ($accessibility == 'voice_control'): ?>
        <script>
            window.SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            const recognition = new SpeechRecognition();
            recognition.continuous = true;
            recognition.start();
            recognition.onresult = (event) => {
                console.log("Voice Command:", event.results[0][0].transcript);
            };
        </script>
    <?php elseif ($accessibility == 'focus_mode'): ?>
        <style>
            body {
                background-color: #f4f4f4;
                font-size: 20px;
            }
        </style>
        <p>Focus mode is enabled. The page is adjusted for better readability.</p>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

    <script src="accessibility.js"></script>
    <script>
        function stopReading() {
            speechSynthesis.cancel(); // Immediately stops any ongoing speech
        }

        document.getElementById("readButton").addEventListener("click", function () {
            stopReading(); // Ensure previous speech stops before starting a new one

            const text = document.body.innerText;
            const speech = new SpeechSynthesisUtterance(text);
            speech.lang = "en-US";
            speech.rate = 1;

            speechSynthesis.speak(speech);
        });
    </script>


</body>

</html>