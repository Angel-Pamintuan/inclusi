<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }

        .title {
            width: 362px;
            height: 117px;

            padding-left: 30px;
            font-weight: 600;
            font-size: 55px;
            line-height: 140%;
            letter-spacing: -0.015em;
            color: #0D0D26;
            margin: 100px auto 0px;
        }

        .backarrow {
            /* keyboard_backspace */

            position: absolute;
            width: 30px;
            height: 30px;
            left: 21px;
            top: 43px;

        }


        .toggle-icon {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 24px;
            cursor: pointer;
            color: #7C7C7C;
        }

        button {
            /* Button */

            /* Auto layout */
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
            padding: 16px 48px;
            gap: 10px;

            position: absolute;
            width: 345px;
            height: 62px;
            left: 24px;
            top: 585px;

            background: #1E4461;
            border-radius: 5px;
            color: white;

        }

        .or-container {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            margin: 90px 0;
        }

        .or-container hr {
            flex-grow: 1;
            border: none;
            border-top: 2px solid #ccc;
            margin: 10px;
        }

        .or-container span {
            padding: 0 10px;
            font-size: 12px;
            font-weight: bold;
            color: #7C7C7C;
        }

        .google {
            /* Group 55 */

            position: absolute;
            width: 48px;
            height: 48px;
            left: 159px;
            top: 685px;


        }

        .login {
            /* Have an account? Log in */

            position: absolute;
            width: 246px;
            height: 29px;
            left: 68px;
            top: 766px;

            font-family: 'SF Pro Display';
            font-style: normal;
            font-weight: 400;
            font-size: 24px;
            line-height: 29px;
            /* identical to box height */
            text-align: center;

            color: #737373;


        }

        .custom-input {
            height: 70px;
            /* Increase input height */
            font-size: 20px;
            /* Bigger text */
            padding: 50px;
            /* More space inside input */
        }

        .custom-label {
            font-size: 18px;
            /* Bigger floating label */
            display: flex;
            align-items: center;
            gap: 8px;
            /* Space between icon and text */
        }

        .custom-label ion-icon {
            font-size: 18px;
            /* Bigger icon */
        }

        form {
            padding-top: 50px;
        }
    </style>

</head>

<body>

    <form method="POST" action="">
        <div class="form-floating mb-3">
            <input type="text" name="companyName" class="form-control custom-input" id="floatingInput"
                placeholder="Company Name">
            <label for="floatingInput" class="custom-label">
                <ion-icon name="person-outline"></ion-icon> Company Name
            </label>
        </div>

        <div class="form-floating mb-3">
            <input type="text" name="jobTitle" class="form-control custom-input" id="floatingInput" placeholder="Title">
            <label for="floatingInput" class="custom-label">
                <ion-icon name="person-outline"></ion-icon> Job Title
            </label>
        </div>

        <div class="form-floating mb-3 position-relative">
            <label for="jobType" class="custom-label">
                <ion-icon name="key-outline"></ion-icon> Password
            </label>
            <select id="jobType" name="jobType">
                <option value="">Full-Time</option>
                <option value="">Part-Time</option>
            </select>
        </div>

        <div class="form-floating mb-3">
            <input type="text" name="contactNumber" class="form-control custom-input" id="floatingInput"
                placeholder="&#8369 ">
            <label for="floatingInput" class="custom-label">
                <ion-icon name="call-outline"></ion-icon> Salary Range
            </label>
        </div>


        <div class="form-floating mb-3 position-relative">
            <input type="text" name="confirmPassword" class="form-control custom-input" id="confirmpassword"
                placeholder="Confirm Password">
            <label for="confirmpassword" class="custom-label">
                <ion-icon name="key-outline"></ion-icon> Confirm Password
            </label>
            <ion-icon name="eye-off-outline" class="toggle-icon"
                onclick="togglePassword('confirmpassword', this)"></ion-icon>
        </div>

        <button type="submit" name="submit">Register</button>
    </form>

</body>

</html>