import speech_recognition as sr
import pyttsx3
import pyautogui
import webbrowser
import time

# Initialize text-to-speech engine
engine = pyttsx3.init()

def speak(text):
    """Make the assistant speak"""
    engine.say(text)
    engine.runAndWait()

def recognize_speech():
    """Listen for voice commands"""
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening for a command...")
        recognizer.adjust_for_ambient_noise(source)
        try:
            audio = recognizer.listen(source, timeout=5)
            command = recognizer.recognize_google(audio).lower()
            print(f"Recognized: {command}")
            return command
        except sr.UnknownValueError:
            speak("Sorry, I didn't understand that.")
        except sr.RequestError:
            speak("Error connecting to speech service.")
        return None

def process_command():
    """Continuously listen and process commands"""
    while True:
        command = recognize_speech()
        if command:
            if "open website" in command:
                speak("Opening website")
                webbrowser.open("http://localhost/InclusiHire/inclusihire/whoyouare.php")  # Change this to your website URL
                time.sleep(3)  # Wait for the page to load

            elif "select applicant" in command:
                speak("Selecting applicant")
                pyautogui.click(x=500, y=400)  # Adjust the coordinates for the button

            elif "select employer" in command:
                speak("Selecting employer")
                pyautogui.click(x=500, y=500)  # Adjust the coordinates for the button

            elif "go to login" in command:
                speak("Going to login page")
                webbrowser.open("http://localhost/login.php")  # Change URL as needed

            elif "scroll down" in command:
                speak("Scrolling down")
                pyautogui.scroll(-500)

            elif "scroll up" in command:
                speak("Scrolling up")
                pyautogui.scroll(500)

            elif "stop" in command:
                speak("Stopping voice assistant")
                break

if __name__ == "__main__":
    speak("Voice assistant activated. Say a command.")
    process_command()
